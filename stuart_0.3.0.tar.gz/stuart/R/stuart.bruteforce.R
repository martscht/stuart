stuart.bruteforce <-
function(
  short.factor.structure, long.equal, item.long.equal,           #made on toplevel
  number.of.items,
  data, factor.structure, auxi,                                  #simple prerequisites
  
  number.of.subtests,  invariance,                               #subtest relations
  repeated.measures, long.invariance,                            #longitudinal relations
  grouping, group.invariance,                                    #grouping relations

  item.invariance, item.long.invariance, item.group.invariance,

  software, cores,                                               #Software to be used

  fitness.func=fitness, ignore.errors=FALSE,                     #fitness function
  
  suppress.model=FALSE, analysis.options=NULL,                   #Additional modeling
  
  filename,

  ...                                                            #All the other stuff
) { #start function

  log <- NULL

  #Give Feedback about combinations
  cat('\n Generating all possible combinations.\n')

  combinations <- do.call('generate.combinations',mget(names(formals(generate.combinations))))

  filter <- combinations$filter
  combi <- combinations$combi

  #creating user feedback
  cat('\n Running STUART with Brute-Force.\n\n')
  progress <- txtProgressBar(width=30,style=3)
  setTxtProgressBar(progress,0)
  count.gb <- 0

  bf.args <- list(filter,combi,
    data,auxi,
    number.of.items,number.of.subtests,
    long.equal,item.long.equal,
    factor.structure,repeated.measures,grouping,
    short.factor.structure,
    invariance,long.invariance,group.invariance,
    item.invariance, item.long.invariance, item.group.invariance,
    analysis.options,suppress.model,
    fitness.func,software,output.model=FALSE,ignore.errors,cores)

  #parallel processing for R-internal estimations
  if (software%in%c('lavaan','OpenMx')) {
    if (cores>1) {
      #set up parallel processing on windows
      if (grepl('Windows',Sys.info()[1],ignore.case=TRUE)) {
        cl <- makeCluster(cores)
        
        #load estimation software to clusters
        parLapply(cl,1:cores,function(x) library(software,character.only=TRUE,quietly=TRUE,verbose=FALSE))
        
        bf.results <- parLapply(cl,1:ants,function(run) {
          setTxtProgressBar(progress, ceiling(run/(10*cores))/(nrow(filter)/(10*cores)));
          do.call('bf.cycle',c(run,bf.args))
        })
        stopCluster(cl)
      }
      
      #run ants in parallel on unixies
      else {
        bf.results <- mclapply(1:nrow(filter),
          function(run) {     
            setTxtProgressBar(progress, ceiling(run/(10*cores))/(nrow(filter)/(10*cores)));
              do.call('bf.cycle',c(run,bf.args))
          },
          mc.cores=cores
        )
      }
    }
    
    else {
      bf.results <- lapply(1:nrow(filter),
        function(run) {     
          setTxtProgressBar(progress, run/nrow(filter));
          do.call('bf.cycle',c(run,bf.args))
        }
      )
    }
  }
  
  #serial processing if Mplus is used (Mplus-internal parallelization is used)
  if (software=='Mplus') {
    bf.args$filename <- filename
    bf.args$cores <- cores
    bf.results <- lapply(1:nrow(filter),
      function(run) {     
        setTxtProgressBar(progress, run/nrow(filter));
        do.call('bf.cycle',c(run,bf.args))
      }
    )
  }
  

  log <- cbind(1:nrow(filter),t(sapply(bf.results, function(x) array(data=unlist(x$solution.phe)))))

  #best solution
  run.gb <- which.max(sapply(bf.results, function(x) return(x$solution.phe$pheromone)))
  phe.gb <- bf.results[[run.gb]]$solution.phe$pheromone
  selected.gb <- bf.results[[run.gb]]$selected

  close(progress)
  cat('\n\n Search ended. \n\n')

  results <- mget(grep('.gb',ls(),value=TRUE))
  results$selected.items <- translate.selection(selected.gb,factor.structure,repeated.measures)
  log <- data.frame(log)
  names(log) <- c('run',names(bf.results[[1]]$solution.phe))
  results$log <- log
  results$pheromones <- NULL
  results$parameters <- NULL
  return(results)

}
