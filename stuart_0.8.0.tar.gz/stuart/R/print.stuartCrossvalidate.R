#' @export

print.stuartCrossvalidate <-
  function(x,...) {
    print(x$comparison)
}
