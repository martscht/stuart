.onAttach <-
function(libname,pkgname) {
  packageStartupMessage('Warning: This is a beta-build of stuart. Please report any bugs you encounter.')
  }