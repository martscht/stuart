#' @export

print.stuartOutput <-
function(x,...) {
  print(x$subtests)
}
